#include "./event.h"

class gold : public event {

	public:	
		gold();
		void message();
		void action(info &);
};
