#include <iostream>
#pragma once 
struct info{
	public:
		int arrows;
		int posR;
		int posC;
		int num;
		bool playing;
		bool wumpus;
		bool gold;
		int wumpusR;
		int wumpusC;
};
